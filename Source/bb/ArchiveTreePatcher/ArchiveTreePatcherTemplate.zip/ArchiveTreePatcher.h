#pragma once

class ArchiveTreePatcher
{
	static bool enabled;

	public:
		static void applyPatches();
};
